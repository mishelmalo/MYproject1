package Facade;

import DAO.CompanyDAO;
import DAO.CouponDAO;
import DAO.CustomerDAO;
import Exceptions.CouponSystemException;
import beans.Company;
import beans.Coupon;
import beans.Customer;
import com.sun.jndi.cosnaming.ExceptionMapper;
import db.*;
import org.omg.IOP.ExceptionDetailMessage;

import java.sql.SQLException;
import java.util.List;

public class AdminFacade extends ClientFacade {
    private CompanyDAO companyDAO = new CompanyDAOImpl();
    private CustomerDAO customerDAO = new CustomerDAOImpl();
    private final String EMAIL="admin@admin.com";
    private final String PASSWORD="admin";

    public  AdminFacade(){

    }

       public boolean login(String email,String password){

        return (email.equals(EMAIL)&&password.equals(PASSWORD));
      }

    public void addCompany(Company company) throws SQLException, CouponSystemException {
     if (companyDAO.isCompanyExistByName(company.getCompanyName()) &&companyDAO.isCompanyExistByEmail(company.getEmail())){
       throw new CouponSystemException("The company already exist by name or email!");
     }
     companyDAO.addCompany(company);
}

    public void updateCompany(Company company) throws SQLException, CouponSystemException {
       // if (!companyDAO.isCompanyExistByID(company.getId())&&companyDAO.isCompanyExistByEmail(company.getEmail())){
     //       throw new CouponSystemException("this email or name company exist! ");
      //  }
        companyDAO.updateCompany(company.getId(),company);
    }
    public void deleteCompany(int companyId ) throws SQLException, CouponSystemException {
        if (!companyDAO.isCompanyExistByID(companyId)){
            throw new CouponSystemException("The company isn't exist!");
        }
        companyDAO.deleteCustomerHistory(companyId);
        companyDAO.deleteCompanyCoupons(companyId);
        companyDAO.deleteCompany(companyId);
    }
    public List<Company> getAllCompanies() throws SQLException {
       return companyDAO.getAllCompanies();

    }
    public Company getOneCompany( int companyId) throws SQLException {
       return companyDAO.getOneCompany(companyId);
    }
    public void addNewCustomer(Customer customer) throws SQLException, CouponSystemException {
       if (customerDAO.isCustomerExistByEmail(customer.getEmail())){
           throw new CouponSystemException("customer email is already exist");
       }
       customerDAO.addCustomer(customer);
    }
    public void updateCustomer(Customer customer) throws SQLException {
        customerDAO.updateCustomer(customer.getId(),customer);
    }
    public void deleteCustomer(int customerID) throws SQLException {
        customerDAO.deltaCustomerCoupon(customerID);
        customerDAO.deltaCustomer(customerID);

    }
    public List<Customer> getAllCustomers() throws SQLException {
       return customerDAO.getAllCustomers();
    }
    public Customer getOneCustomer(int customerId) throws SQLException {
       return customerDAO.getOneCustomer(customerId);
    }

}
