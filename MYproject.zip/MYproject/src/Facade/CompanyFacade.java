package Facade;

import Exceptions.CouponSystemException;
import beans.Category;
import beans.Company;
import beans.Coupon;
import DAO.CompanyDAO;
import db.CompanyDAOImpl;
import DAO.CouponDAO;
import db.CouponDAOImpl;

import java.sql.SQLException;
import java.util.List;

public class CompanyFacade extends ClientFacade {
    private int companyID;
    private CompanyDAO companyDAO=new CompanyDAOImpl();
    private CouponDAO couponDAO=new CouponDAOImpl();

    public CompanyFacade() {
    }

    public boolean login(String email,String password) throws SQLException, CouponSystemException {
      if (!companyDAO.isCompanyExist(email,password)){
          throw new CouponSystemException("company doesn't exist!");
      }
      this.companyID=companyDAO.findCompany(email, password);
      return true;

    }
    public void addCoupon(Coupon coupon) throws SQLException, CouponSystemException {
     if(couponDAO.ISCompanyCouponTitleExist(companyID,coupon.getTitle())){
         throw new CouponSystemException("the company already have that coupon title!!");
     }

        couponDAO.addCoupon(coupon);

    }
    public void updateCoupon(Coupon coupon) throws SQLException {


        couponDAO.updateCouponWithoutCompanyID(companyID,coupon);

    }
    public void deleteCoupon(int couponID) throws SQLException {
        couponDAO.deleteCouponHistory(couponID);
        couponDAO.deleteCoupon(couponID);
    }
    public List<Coupon> getAllCompanyCoupons() throws SQLException {
       return couponDAO.getAllCompanyCoupons(companyID);

    }
    public List<Coupon>getAllCompanyCouponsOnOneCategory(Category category) throws SQLException {
        return couponDAO.getAllCompanyCouponsOnOneCategory(companyID,category.ordinal()+1);
    }
public List<Coupon>getAllCompanyCouponsLimitedByMaxPrice(int maxPrice) throws SQLException {
        return couponDAO.getAllCompanyCouponsLimitedByMaxPrice(companyID,maxPrice);
}
public Company getCompanyThatLogin() throws SQLException {
        return companyDAO.getOneCompany(companyID);
}
public Coupon getOneCoupon(int couponID) throws SQLException {
        return couponDAO.getOneCoupon(couponID);
}

}