package Facade;

import DAO.CouponDAO;
import DAO.CustomerDAO;
import Exceptions.CouponSystemException;
import beans.Category;
import beans.Coupon;
import beans.Customer;
import db.CouponDAOImpl;
import db.CustomerDAOImpl;

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class CustomerFacade extends ClientFacade {
    private int CustomerID;
    private CustomerDAO customerDAO=new CustomerDAOImpl();
    private CouponDAO couponDAO=new CouponDAOImpl();

    public CustomerFacade(){

    }
    public boolean login(String email,String password) throws SQLException, CouponSystemException {
        if (!customerDAO.isCustomerExist(email,password)){
            throw new CouponSystemException("customer not exist! ");
        }
        this.CustomerID=customerDAO.findCustomer(email, password);
        return true;
    }
    public void purchaseCoupon(Coupon coupon) throws SQLException, CouponSystemException {
        if (customerDAO.isCustomerBuyTheCoupon(CustomerID,coupon.getId())){
            throw new CouponSystemException("you already by that coupon");
        }
        if (coupon.getAmount()<=0){
            throw new CouponSystemException("coupon sold out");

        }
        if (coupon.getEndDate().before(Date.valueOf(LocalDate.now()))){
            throw new CouponSystemException("coupon date is expired");
        }
        couponDAO.addCouponPurchase(CustomerID,coupon.getId());
        coupon.setAmount(coupon.getAmount()-1);
        couponDAO.updateCoupon(coupon.getId(),coupon);

}
public List<Coupon>getCustomerCoupons() throws SQLException {
        return customerDAO.getAllCustomersCoupons(CustomerID);

}
public List<Coupon> getAllCustomersCouponsByCategory( Category category) throws SQLException {
       return customerDAO.getAllCustomersCouponsByCategory(CustomerID,category.ordinal()+1);
}
public List<Coupon>getAllCustomersCouponsUnderMaxPrice(int maxPrice) throws SQLException {
        return customerDAO.getAllCustomersCouponsUnderMaxPrice(CustomerID,maxPrice) ;
}
public Customer getCustomerDetails() throws SQLException {
       return customerDAO.getOneCustomer(CustomerID);
}
public List<Coupon>couponsForChoose() throws SQLException {
        return couponDAO.getAllCoupons();
}
}
