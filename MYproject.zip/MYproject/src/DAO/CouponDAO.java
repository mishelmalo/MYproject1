package DAO;

import beans.Coupon;

import java.sql.SQLException;
import java.util.List;

public interface CouponDAO {
    void addCoupon(Coupon coupon) throws SQLException;
    void updateCoupon(int couponID,Coupon coupon) throws SQLException;
    void updateCouponWithoutCompanyID(int companyID,Coupon coupon) throws SQLException;
    void deleteCoupon(int couponID) throws SQLException;
    void deleteCouponHistory(int couponID) throws SQLException;

    List<Coupon> getAllCoupons() throws SQLException;
    List<Coupon> getAllCompanyCoupons(int companyID) throws SQLException;
    List<Coupon> getAllCompanyCouponsOnOneCategory(int companyID,int categoryID) throws SQLException;
    List<Coupon> getAllCompanyCouponsLimitedByMaxPrice(int companyID,int max) throws SQLException;
    Coupon getOneCoupon(int couponID) throws SQLException;
    void addCouponPurchase(int customerID,int couponID) throws SQLException;
    void deleteCouponPurchase(int customerID,int couponID) throws SQLException;
    boolean ISCompanyCouponTitleExist(int companyID,String title) throws SQLException;



}
