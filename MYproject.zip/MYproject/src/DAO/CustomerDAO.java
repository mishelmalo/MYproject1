package DAO;

import beans.Coupon;
import beans.Customer;

import java.sql.SQLException;
import java.util.List;

public interface CustomerDAO {
    boolean isCustomerExist(String email,String password) throws SQLException;
    boolean isCustomerExistByEmail(String email) throws SQLException;
    int findCustomer(String email,String password) throws SQLException;
    void addCustomer(Customer customer) throws SQLException;
    void updateCustomer(int customerID,Customer customer) throws SQLException;
    void deltaCustomer(int customerID) throws SQLException;
    void deltaCustomerCoupon(int customerID) throws SQLException;
    List<Customer> getAllCustomers() throws SQLException;
    Customer getOneCustomer(int customerID) throws SQLException;
    boolean isCustomerBuyTheCoupon(int customerID,int couponID) throws SQLException;
    List<Coupon> getAllCustomersCoupons(int customerID) throws SQLException;
    List<Coupon> getAllCustomersCouponsByCategory(int customerID,int categoryID) throws SQLException;
    List<Coupon> getAllCustomersCouponsUnderMaxPrice(int customerID,int maxPrice) throws SQLException;


}
