package DAO;

import beans.Company;
import beans.Coupon;
import beans.Customer;

import java.sql.SQLException;
import java.util.List;

public interface CompanyDAO {
    boolean isCompanyExist(String email,String password) throws SQLException;
    boolean isCompanyExistByName(String nameCompany) throws SQLException;
    boolean isCompanyExistByEmail(String email) throws SQLException;
    boolean isCompanyExistByID(int id) throws SQLException;
    int findCompany(String email,String password) throws SQLException;
    void addCompany(Company company) throws SQLException;
    void updateCompany(int companyID,Company company) throws SQLException;
    void deleteCompany(int companyID) throws SQLException;
    void deleteCompanyCoupons(int companyID) throws SQLException;
    void deleteCustomerHistory( int companyID) throws SQLException;


    List<Company>getAllCompanies() throws SQLException;
    Company getOneCompany(int companyID) throws SQLException;




}
