package LoginM;

public enum ClientType {
    ADMINISTRATOR,COMPANY,CUSTOMER
}
