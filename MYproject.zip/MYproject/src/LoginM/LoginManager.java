package LoginM;

import Exceptions.CouponSystemException;
import Facade.AdminFacade;
import Facade.ClientFacade;
import Facade.CompanyFacade;
import Facade.CustomerFacade;

import java.sql.SQLException;

public class LoginManager {
    private static LoginManager instance=null;


    public static LoginManager getInstance(){
        if (instance==null){
            synchronized (LoginManager.class){
                if (instance==null){
                      instance = new LoginManager();
                }
            }
        }

        return instance;
    }
    public LoginManager() {

    }
    public ClientFacade login(String email,String password,ClientType clientType) throws SQLException, CouponSystemException {
        AdminFacade adminFacade = new AdminFacade();
        CompanyFacade companyFacade = new CompanyFacade();
        CustomerFacade customerFacade = new CustomerFacade();

        switch (clientType) {
            case ADMINISTRATOR: {
                if (adminFacade.login(email, password)) {
                    return adminFacade;
                }
            }
            case COMPANY: {
                if (companyFacade.login(email, password)) {
                    return companyFacade;
                }
            }
            case CUSTOMER: {
                if (customerFacade.login(email, password)) {
                    return customerFacade;
                }
            }
        }

    return null;
    }
}
