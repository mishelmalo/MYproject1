package Test;

import DAO.CompanyDAO;
import DAO.CouponDAO;
import DAO.CustomerDAO;
import Exceptions.CouponSystemException;
import Facade.AdminFacade;
import Facade.CompanyFacade;
import Facade.CustomerFacade;
import Job.CouponExpirationDailyJob;
import LoginM.ClientType;
import LoginM.LoginManager;
import beans.Category;
import beans.Company;
import beans.Coupon;
import beans.Customer;
import db.CompanyDAOImpl;
import db.ConnectionPool;
import db.CouponDAOImpl;
import db.CustomerDAOImpl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.Calendar;

public class FinalTest {
    public static void main(String[] args) throws SQLException {

       Thread job=new Thread(new CouponExpirationDailyJob());
        job.start();

        AdminFacade adminFacade=null;
        System.out.println("********************* admin test-login *******************");
        LoginManager loginManager1=LoginManager.getInstance();
        try {
            adminFacade=(AdminFacade) loginManager1.login("admin@admin.com","admin", ClientType.ADMINISTRATOR);
        } catch (CouponSystemException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        System.out.println("************** add company  *****************");
        try {
            adminFacade.addCompany(new Company("BLIK","blik_123@.com","blikk"));
            adminFacade.addCompany(new Company("DOMINOS_PIZZA","dominos45@gmail.com","dominosp"));
            adminFacade.addCompany(new Company("VENUS","venus@.com","venus24"));
            adminFacade.addCompany(new Company("el al","el_al@gmail.com","elal2435"));
        } catch (CouponSystemException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
       adminFacade.getAllCompanies().forEach(System.out::println);

        System.out.println("***************** delete company by id **************");
        try {
            adminFacade.deleteCompany(4);
        } catch (CouponSystemException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        adminFacade.getAllCompanies().forEach(System.out::println);

        System.out.println("**************** update company name - fail *************");
        Company companyDb=adminFacade.getOneCompany(2);
        companyDb.setCompanyName("pizza_hut");
        try {
            adminFacade.updateCompany(companyDb);
        } catch (SQLException | CouponSystemException e) {
            e.printStackTrace();
        }
        System.out.println(adminFacade.getOneCompany(2)+"\n");

        System.out.println("********** update company success*************");
        Company companyDb4=adminFacade.getOneCompany(2);
        companyDb4.setPassword("domi45");
        try {
            adminFacade.updateCompany(companyDb4);
        } catch (SQLException | CouponSystemException e) {
            e.printStackTrace();
        }
        System.out.println(adminFacade.getOneCompany(2)+"\n");
        System.out.println("**************** get all companies ***************");
        adminFacade.getAllCompanies().forEach(System.out::println);

        System.out.println("*********** add customer *************");
        try {
            adminFacade.addNewCustomer(new Customer("hila","david","hila_d@gmail.com","hila3v"));
            adminFacade.addNewCustomer(new Customer("kobi","levi","kobi45@gmail.com","kobif4"));
            adminFacade.addNewCustomer(new Customer("shay","alon","shay65@gmail.com","sha3f"));
            adminFacade.addNewCustomer(new Customer("or","tal","or_tal@gmail.com","ort466"));
        } catch (CouponSystemException e)
        {
            e.printStackTrace();
        }catch (SQLException e) {
            e.printStackTrace();
        }
       adminFacade.getAllCustomers().forEach(System.out::println);

        System.out.println("****************** delete customer *****************");
        try {
            adminFacade.deleteCustomer(4);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        adminFacade.getAllCustomers().forEach(System.out::println);

        System.out.println("********** update customer  ******************");
        Customer customerdb1=adminFacade.getOneCustomer(3);
        customerdb1.setLastName("aloon");
        try {
            adminFacade.updateCustomer(customerdb1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(adminFacade.getOneCustomer(3)+"\n");

        System.out.println("*********** get all customers ****************");
        adminFacade.getAllCustomers().forEach(System.out::println);



        //*************************************************** company facade ****************************************

        CompanyFacade companyFacade=null;
        System.out.println("********************* company test-login *******************");
        LoginManager loginManager2=LoginManager.getInstance();
        try {
            companyFacade=(CompanyFacade) loginManager2.login("venus@.com","venus24", ClientType.COMPANY);
        } catch (CouponSystemException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        System.out.println("******************** add coupon **************************");
        Calendar calendar1=Calendar.getInstance();
        calendar1.set(2022,7,14);
        Calendar calendar2=Calendar.getInstance();
        calendar2.set(2022,8,23);
        Calendar calendar3=Calendar.getInstance();
        calendar3.set(2022,5,10);
        Calendar calendar4=Calendar.getInstance();
        calendar4.set(2022,5,21);
        Calendar calendar5=Calendar.getInstance();
        calendar5.set(2022,6,20);
        Calendar calendard=Calendar.getInstance();
        calendard.set(2022,6,14);
        Calendar calendardd=Calendar.getInstance();
        calendardd.set(2022,8,23);
        try {
            companyFacade.addCoupon(new Coupon(3, Category.HEAR_REMOVAL,"venus razor","6 venus razor extra soft",
                    new Date(calendar1.getTimeInMillis()),new Date(calendar2.getTimeInMillis()),3,66.70,"gmh"));
            companyFacade.addCoupon(new Coupon(3, Category.HEAR_REMOVAL,"venus razor soft","10 venus razor extra soft",
                    new Date(calendar3.getTimeInMillis()),new Date(calendar5.getTimeInMillis()),2,109.10,"dgd"));
            companyFacade.addCoupon(new Coupon(3, Category.HEAR_REMOVAL,"venus wax","21 venus wax hear remover",
                    new Date(calendar3.getTimeInMillis()),new Date(calendar4.getTimeInMillis()),3,66.70,"gmh"));
           // companyFacade.addCoupon(new Coupon(3, Category.HEAR_REMOVAL,"venus wax","50 venus wax hear remover",
             //       new Date(calendar3.getTimeInMillis()),new Date(calendar4.getTimeInMillis()),2,109.10,"dgd"));
            companyFacade.addCoupon(new Coupon(3, Category.HEAR_REMOVAL,"venus wax extra","21 venus wax hear remover",
                    new Date(calendar3.getTimeInMillis()),new Date(calendar5.getTimeInMillis()),3,66.70,"gmh"));

            companyFacade.addCoupon(new Coupon(2,Category.RESTAURANT,"xl pizza for sale","2 xl pizza with 4 tops",new Date(calendard.getTimeInMillis()),
                   new Date(calendardd.getTimeInMillis()),45,98.45,"sfd"));
        } catch (CouponSystemException e) {
            e.printStackTrace();
        }catch (SQLException e) {
            e.printStackTrace();
       }
        companyFacade.getAllCompanyCoupons().forEach(System.out::println);


        System.out.println("************* delete coupon ******************");
        try {
            companyFacade.deleteCoupon(4);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        companyFacade.getAllCompanyCoupons().forEach(System.out::println);

        System.out.println("****************** update coupon ****************");
        Coupon coupondb2=companyFacade.getOneCoupon(2);
        coupondb2.setAmount(1);
        try {
            companyFacade.updateCoupon(coupondb2);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        companyFacade.getAllCompanyCoupons().forEach(System.out::println);

        System.out.println("********* get company coupons by category");
        System.out.println(companyFacade.getAllCompanyCouponsOnOneCategory(Category.HEAR_REMOVAL)+"\n");
        System.out.println("************* get company coupons under max price ********* ");
        System.out.println(companyFacade.getAllCompanyCouponsLimitedByMaxPrice(90)+"\n");
        System.out.println(companyFacade.getCompanyThatLogin()+"\n");





        //**************************************** customer facade  ****************************************************

        CustomerFacade customerFacade=null;
        System.out.println("********************* customer test-login *******************");
        LoginManager loginManager3=LoginManager.getInstance();
        try {
            customerFacade=(CustomerFacade) loginManager3.login("hila_d@gmail.com","hila3v", ClientType.CUSTOMER);
        } catch (CouponSystemException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        System.out.println("***************** buy coupon 1 ********************");
        Coupon couponDB=customerFacade.couponsForChoose().get(1);
        try {
            customerFacade.purchaseCoupon(couponDB);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (CouponSystemException e) {
            e.printStackTrace();
        }
       try {
            customerFacade.purchaseCoupon(couponDB);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (CouponSystemException e) {
            e.printStackTrace();
        }
        customerFacade.getCustomerCoupons().forEach(System.out::println);

        System.out.println("***************** buy coupon 2 ********************");
        Coupon couponDB2=customerFacade.couponsForChoose().get(2);
        try {
            customerFacade.purchaseCoupon(couponDB2);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (CouponSystemException e) {
            e.printStackTrace();
        }
        customerFacade.getCustomerCoupons().forEach(System.out::println);
        System.out.println("***************** buy coupon 3 ********************");
        Coupon couponDB3=customerFacade.couponsForChoose().get(4);
        try {
            customerFacade.purchaseCoupon(couponDB3);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (CouponSystemException e) {
            e.printStackTrace();
        }

        customerFacade.getCustomerCoupons().forEach(System.out::println);

        System.out.println("********** customer coupons by category *****************");
        System.out.println(customerFacade.getAllCustomersCouponsByCategory(Category.HEAR_REMOVAL)+"\n");
        System.out.println("********** customer coupons by max price *****************");
        System.out.println(customerFacade.getAllCustomersCouponsUnderMaxPrice(100)+"\n");
        System.out.println("********** customer details *****************");
        System.out.println(customerFacade.getCustomerDetails()+"\n");
        System.out.println("**************** coupons  *********************");
        System.out.println(customerFacade.couponsForChoose()+"\n");

        ConnectionPool.getInstance().CloseAllConnections();
    }
}
