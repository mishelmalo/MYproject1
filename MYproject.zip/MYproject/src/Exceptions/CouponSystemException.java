package Exceptions;

public class CouponSystemException extends Exception {
    public CouponSystemException(String message){
        super(message);
    }
}
