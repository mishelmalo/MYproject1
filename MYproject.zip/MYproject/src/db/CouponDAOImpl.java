package db;

import DAO.CouponDAO;
import beans.Category;
import beans.Coupon;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CouponDAOImpl implements CouponDAO {
    private ConnectionPool pool=ConnectionPool.getInstance();
    @Override
    public void addCoupon(Coupon coupon) throws SQLException {
        Connection con=pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("insert into coupons" +
                    " (company_id,category_id,title,description,start_date,end_date,amount,price,image) values(?,?,?,?,?,?,?,?,?)");

            statement.setInt(1, coupon.getCompanyID());
            statement.setInt(2, coupon.getCategory().ordinal() + 1);
            statement.setString(3, coupon.getTitle());
            statement.setString(4, coupon.getDescription());
            statement.setDate(5, coupon.getStartDate());
            statement.setDate(6, coupon.getEndDate());
            statement.setInt(7, coupon.getAmount());
            statement.setDouble(8, coupon.getPrice());
            statement.setString(9, coupon.getImage());
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
    } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public void updateCoupon(int couponID,Coupon coupon) throws SQLException {
        Connection con=pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("update coupons set company_id=?,category_id=?,title=?," +
                    "description=?,start_date=?,end_date=?,amount=?,price=?,image=? where id= " + couponID);

            statement.setInt(1, coupon.getCompanyID());
            statement.setInt(2, coupon.getCategory().ordinal() + 1);
            statement.setString(3, coupon.getTitle());
            statement.setString(4, coupon.getDescription());
            statement.setDate(5, coupon.getStartDate());
            statement.setDate(6, coupon.getEndDate());
            statement.setInt(7, coupon.getAmount());
            statement.setDouble(8, coupon.getPrice());
            statement.setString(9, coupon.getImage());
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();

    } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public void updateCouponWithoutCompanyID(int companyID, Coupon coupon) throws SQLException {
        Connection con=pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("update coupons set category_id=?,title=?," +
                    "description=?,start_date=?,end_date=?,amount=?,price=?,image=? where id=" + coupon.getId() + " and company_id=" + companyID);

            statement.setInt(1, coupon.getCategory().ordinal() + 1);
            statement.setString(2, coupon.getTitle());
            statement.setString(3, coupon.getDescription());
            statement.setDate(4, coupon.getStartDate());
            statement.setDate(5, coupon.getEndDate());
            statement.setInt(6, coupon.getAmount());
            statement.setDouble(7, coupon.getPrice());
            statement.setString(8, coupon.getImage());
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();

    } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public void deleteCoupon(int couponID) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("delete from coupons where id= " + couponID);
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
    } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public void deleteCouponHistory(int couponID) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("delete from customers_vs_coupons where coupon_id= " + couponID);
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
    } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public List<Coupon> getAllCoupons() throws SQLException {
        Connection con= pool.getConnection();
        try {
            List<Coupon> coupons = new ArrayList<>();
            PreparedStatement statement = con.prepareStatement("select*from coupons");
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                coupons.add(new Coupon(rs.getInt(1), rs.getInt(2), Category.values()[rs.getInt(3) - 1],
                        rs.getString(4), rs.getString(5), rs.getDate(6), rs.getDate(7),
                        rs.getInt(8), rs.getDouble(9), rs.getString(10)));
            }
            return coupons;

        } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public List<Coupon> getAllCompanyCoupons(int companyID) throws SQLException {
        Connection con= pool.getConnection();
        try {
            List<Coupon> coupons = new ArrayList<>();
            PreparedStatement statement = con.prepareStatement("select*from coupons where company_id= " + companyID);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                coupons.add(new Coupon(rs.getInt(1), rs.getInt(2), Category.values()[rs.getInt(3) - 1],
                        rs.getString(4), rs.getString(5), rs.getDate(6), rs.getDate(7),
                        rs.getInt(8), rs.getDouble(9), rs.getString(10)));
            }
            return coupons;

        } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public List<Coupon> getAllCompanyCouponsOnOneCategory(int companyID,int categoryID) throws SQLException {
        Connection con= pool.getConnection();
        try {
            List<Coupon> coupons = new ArrayList<>();
            PreparedStatement statement = con.prepareStatement("select*from coupons where company_id=? and category_id=? ");
            statement.setInt(1, companyID);
            statement.setInt(2, categoryID);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                coupons.add(new Coupon(rs.getInt(1), rs.getInt(2), Category.values()[rs.getInt(3) - 1],
                        rs.getString(4), rs.getString(5), rs.getDate(6), rs.getDate(7),
                        rs.getInt(8), rs.getDouble(9), rs.getString(10)));
            }
            return coupons;
        } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public List<Coupon> getAllCompanyCouponsLimitedByMaxPrice(int companyID,int maxPrice) throws SQLException {
        Connection con= pool.getConnection();
        try {
            List<Coupon> coupons = new ArrayList<>();
            PreparedStatement statement = con.prepareStatement("select*from coupons where company_id=? and price<=? ");
            statement.setInt(1, companyID);
            statement.setInt(2, maxPrice);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                coupons.add(new Coupon(rs.getInt(1), rs.getInt(2), Category.values()[rs.getInt(3) - 1],
                        rs.getString(4), rs.getString(5), rs.getDate(6), rs.getDate(7),
                        rs.getInt(8), rs.getDouble(9), rs.getString(10)));
            }
            return coupons;

        } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public Coupon getOneCoupon(int couponID) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("select*from coupons where id= " + couponID);
            ResultSet rs = statement.executeQuery();
            rs.next();
            Coupon coupon = new Coupon(rs.getInt(1), rs.getInt(2), Category.values()[rs.getInt(3) - 1],
                    rs.getString(4), rs.getString(5), rs.getDate(6), rs.getDate(7), rs.getInt(8),
                    rs.getDouble(9), rs.getString(10));
            return coupon;

    } finally {
            pool.restoreConnection(con);
        }

    }

    @Override
    public void addCouponPurchase(int customerID, int couponID) throws SQLException {
            Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("insert into customers_vs_coupons" +
                    "(customer_id,coupon_id) values(?,?)");
            statement.setInt(1, customerID);
            statement.setInt(2, couponID);
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();

    } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public void deleteCouponPurchase(int customerID, int couponID) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("delete from customers_vs_coupons where" +
                    " customer_id= " + customerID + " and coupon_id= " + couponID);

            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();

    } finally {
            pool.restoreConnection(con);
        }

    }



    @Override
    public boolean ISCompanyCouponTitleExist(int companyID,String title) throws SQLException {
            Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("select*from coupons where company_id=? and title=? ");
            statement.setInt(1, companyID);
            statement.setString(2, title);
            ResultSet rs = statement.executeQuery();
            boolean isTitle = false;
            if (rs.next()) {
                isTitle = true;
            }
            return isTitle;
        } finally {
            pool.restoreConnection(con);
        }
    }

}
