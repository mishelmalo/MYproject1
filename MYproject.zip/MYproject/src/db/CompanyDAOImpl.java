package db;

import DAO.CompanyDAO;
import beans.Category;
import beans.Company;
import beans.Coupon;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CompanyDAOImpl implements CompanyDAO {
    private ConnectionPool pool=ConnectionPool.getInstance();

    @Override
    public boolean isCompanyExist(String email, String password) throws SQLException {
        Connection con= pool.getConnection();
        try {

            PreparedStatement statement = con.prepareStatement("select id from companies where email=? and password= ? ");
            statement.setString(1, email);
            statement.setString(2, password);
            ResultSet rs = statement.executeQuery();
            boolean id = false;
            if (rs.next()) {
                id = true;
            }

            return id;
        } finally {
            pool.restoreConnection(con);
        }

    }

    @Override
    public boolean isCompanyExistByName(String nameCompany) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("select * from companies where name=? ");
            statement.setString(1, nameCompany);
            ResultSet rs = statement.executeQuery();
            boolean name = false;
            if (rs.next()) {
                name = true;
            }
            return name;
        } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public boolean isCompanyExistByEmail(String email) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("select * from companies where email=? ");
            statement.setString(1, email);
            ResultSet rs = statement.executeQuery();
            boolean isEmail = false;
            if (rs.next()) {
                isEmail = true;
            }
            return isEmail;
        } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public boolean isCompanyExistByID(int id) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("select * from companies where id=? ");
            statement.setInt(1, id);
            ResultSet rs = statement.executeQuery();
            boolean isID = false;
            if (rs.next()) {
                isID = true;
            }
            return isID;
        } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public int findCompany(String email, String password) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("select id from companies where email=? and password= ? ");
            statement.setString(1, email);
            statement.setString(2, password);
            ResultSet rs = statement.executeQuery();
            int id = -1;
            if (rs.next()) {
                id = rs.getInt(1);
            }
            return id;
        } finally {
            pool.restoreConnection(con);
        }
    }


    @Override
    public void addCompany(Company company) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement=con.prepareStatement("insert into companies (name,email,password) values(?,?,?)");
            statement.setString(1, company.getCompanyName());
            statement.setString(2, company.getEmail());
            statement.setString(3, company.getPassword());
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            pool.restoreConnection(con);
        }

    }

    @Override
    public void updateCompany(int companyID,Company company) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("update companies set email=?,password=?" +
                    " where id= " + companyID);
            statement.setString(1, company.getEmail());
            statement.setString(2, company.getPassword());
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
    } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public void deleteCompany(int companyID) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("delete from companies where id= " + companyID);
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
       } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public void deleteCompanyCoupons(int companyID) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement=con.prepareStatement("delete from coupons where company_id= "+companyID);
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            pool.restoreConnection(con);
        }


    }

    @Override
    public void deleteCustomerHistory(int companyID) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("delete from customers_vs_coupons where coupon_id=? ");
            statement.setInt(1, getCompanyCouponsID(companyID));
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
    } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public List<Company> getAllCompanies() throws SQLException {
        Connection con= pool.getConnection();
        try {
            ArrayList<Company> companies = new ArrayList<>();
            PreparedStatement statement = con.prepareStatement("select*from companies");
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                companies.add(new Company(rs.getInt(1), rs.getString(2),
                        rs.getString(3), rs.getString(4), getCompanyCoupons(rs.getInt(1))));
            }
            return companies;

        } finally {
            pool.restoreConnection(con);
        }

    }

    @Override
    public Company getOneCompany(int companyID) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("select *from companies where id= " + companyID);
            ResultSet rs = statement.executeQuery();
            rs.next();
            Company comp = new Company(rs.getInt(1), rs.getString(2), rs.getString(3),
                    rs.getString(4), getCompanyCoupons(companyID));
            return comp;
        } finally {
            pool.restoreConnection(con);
        }
    }

    public List<Coupon> getCompanyCoupons(int companyID) throws SQLException {
        Connection con= pool.getConnection();
        try {
            List<Coupon> coupons = new ArrayList<>();
            PreparedStatement statement = con.prepareStatement
                    ("select*from coupons where company_id= " + companyID);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                coupons.add(new Coupon(rs.getInt(1), rs.getInt(2),
                        Category.values()[rs.getInt(3) - 1], rs.getString(4), rs.getString(5),
                        rs.getDate(6), rs.getDate(7), rs.getInt(8), rs.getDouble(9), rs.getString(10)));
            }
            return coupons;
        } finally {
            pool.restoreConnection(con);
        }

    }
    public int getCompanyCouponsID(int companyID) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("select*from coupons where company_id= " + companyID);
            ResultSet rs = statement.executeQuery();
            int idCoupons = 1;
            if (rs.next()) {
                idCoupons = rs.getInt(1);
            } return idCoupons;
        } finally {
            pool.restoreConnection(con);
        }

    }


}
