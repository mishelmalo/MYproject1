package db;

import DAO.CustomerDAO;
import beans.Category;
import beans.Coupon;
import beans.Customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerDAOImpl implements CustomerDAO {
    public ConnectionPool pool=ConnectionPool.getInstance();
    @Override
    public boolean isCustomerExist(String email, String password) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("select id from customers where email= ? and password= ?");
            statement.setString(1, email);
            statement.setString(2, password);
            ResultSet rs = statement.executeQuery();
            boolean id = false;
            if (rs.next()) {
                id = true;
            }
            return id;
    } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public boolean isCustomerExistByEmail(String email) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("select * from customers where email=? ");
            statement.setString(1, email);
            ResultSet rs = statement.executeQuery();
            boolean isEmail = false;
            if (rs.next()) {
                isEmail = true;
            }
            return isEmail;
        } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public int findCustomer(String email, String password) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("select id from customers where email= ? and password= ?");
            statement.setString(1, email);
            statement.setString(2, password);
            ResultSet rs = statement.executeQuery();
            int id = -1;
            if (rs.next()) {
                id = rs.getInt(1);
            }
            return id;

        } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public void addCustomer(Customer customer) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("insert into customers (first_name,last_name,email,password) values(?,?,?,?)");
            statement.setString(1, customer.getFirstName());
            statement.setString(2, customer.getLastName());
            statement.setString(3, customer.getEmail());
            statement.setString(4, customer.getPassword());
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
    } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public void updateCustomer(int customerID,Customer customer) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("update customers set first_name=?,last_name=?,email=?,password=? " +
                    "where id=" + customer.getId());
            statement.setString(1, customer.getFirstName());
            statement.setString(2, customer.getLastName());
            statement.setString(3, customer.getEmail());
            statement.setString(4, customer.getPassword());
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();

    } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public void deltaCustomer(int customerID) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("delete from customers where id= " + customerID);
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
    } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public void deltaCustomerCoupon(int customerID) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("delete from customers_vs_coupons where customer_id= " + customerID);
            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
    } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public List<Customer> getAllCustomers() throws SQLException {
        Connection con= pool.getConnection();
        try {
            ArrayList<Customer> customers = new ArrayList<>();
            PreparedStatement statement = con.prepareStatement("select*from customers");
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                customers.add(new Customer(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
                        rs.getString(5), getCustomerCoupons(rs.getInt(1))));
            }
            return customers;

        } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public Customer getOneCustomer(int customerID) throws SQLException {
        Connection con= pool.getConnection();
        try {

            PreparedStatement statement = con.prepareStatement("select *from customers where  id= " + customerID);
            ResultSet rs = statement.executeQuery();
            rs.next();
            Customer customer = new Customer(rs.getInt(1), rs.getString(2), rs.getString(3),
                    rs.getString(4), rs.getString(5), getCustomerCoupons(customerID));
            return customer;
        } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public boolean isCustomerBuyTheCoupon(int customerID, int couponID) throws SQLException {
        Connection con= pool.getConnection();
        try {
            PreparedStatement statement = con.prepareStatement("select*from customers_vs_coupons where customer_id=? and coupon_id=? ");
            statement.setInt(1, customerID);
            statement.setInt(2, couponID);
            ResultSet rs = statement.executeQuery();
            boolean sold = false;
            if (rs.next()) {
                sold = true;
            }
            return sold;
        } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public List<Coupon> getAllCustomersCoupons(int customerID) throws SQLException {
        Connection con= pool.getConnection();
        try {
            List<Coupon> coupons = new ArrayList<>();
            PreparedStatement statement = con.prepareStatement
                    ("select coupons.id, coupons.company_id, coupons.category_id,coupons.title, coupons.description, coupons.start_date," +
                            " coupons.end_date, coupons.amount, coupons.price, coupons.image" +
                            " from  customers_vs_coupons join coupons" +
                            " where customers_vs_coupons.coupon_id = coupons.id" +
                            " and  customers_vs_coupons.customer_id=? ");
            statement.setInt(1, customerID);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                coupons.add(new Coupon(rs.getInt(1), rs.getInt(2),
                        Category.values()[rs.getInt(3) - 1], rs.getString(4), rs.getString(5),
                        rs.getDate(6), rs.getDate(7), rs.getInt(8), rs.getDouble(9), rs.getString(10)));
            }
            return coupons;
        } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public List<Coupon> getAllCustomersCouponsByCategory(int customerID, int categoryID) throws SQLException {
        Connection con= pool.getConnection();
        try {
            List<Coupon> coupons = new ArrayList<>();
            PreparedStatement statement = con.prepareStatement("select coupons.id, coupons.company_id, coupons.category_id,coupons.title, coupons.description, coupons.start_date," +
                    " coupons.end_date, coupons.amount, coupons.price, coupons.image" +
                    " from  customers_vs_coupons join coupons" +
                    " where customers_vs_coupons.coupon_id = coupons.id" +
                    " and  customers_vs_coupons.customer_id=? and coupons.category_id=? ");
            statement.setInt(1, customerID);
            statement.setInt(2, categoryID);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                coupons.add(new Coupon(rs.getInt(1), rs.getInt(2), Category.values()[rs.getInt(3) - 1],
                        rs.getString(4), rs.getString(5), rs.getDate(6), rs.getDate(7),
                        rs.getInt(8), rs.getDouble(9), rs.getString(10)));
            }
            return coupons;
        } finally {
            pool.restoreConnection(con);
        }
    }

    @Override
    public List<Coupon> getAllCustomersCouponsUnderMaxPrice(int customerID, int maxPrice) throws SQLException {
        Connection con= pool.getConnection();
        try {
            List<Coupon> coupons = new ArrayList<>();
            PreparedStatement statement = con.prepareStatement("select coupons.id, coupons.company_id, coupons.category_id,coupons.title, coupons.description, coupons.start_date," +
                    " coupons.end_date, coupons.amount, coupons.price, coupons.image" +
                    " from  customers_vs_coupons join coupons" +
                    " where customers_vs_coupons.coupon_id = coupons.id" +
                    " and  customers_vs_coupons.customer_id=? and price<=? ");
            statement.setInt(1, customerID);
            statement.setInt(2, maxPrice);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                coupons.add(new Coupon(rs.getInt(1), rs.getInt(2), Category.values()[rs.getInt(3) - 1],
                        rs.getString(4), rs.getString(5), rs.getDate(6), rs.getDate(7),
                        rs.getInt(8), rs.getDouble(9), rs.getString(10)));
            }
            return coupons;
        } finally {
            pool.restoreConnection(con);
        }
    }


    public List<Coupon> getCustomerCoupons(int customerID) throws SQLException {
        Connection con= pool.getConnection();
        try {
            List<Coupon> coupons = new ArrayList<>();
            PreparedStatement statement = con.prepareStatement
                    ("select coupons.id, coupons.company_id, coupons.category_id,coupons.title, coupons.description, coupons.start_date," +
                            " coupons.end_date, coupons.amount, coupons.price, coupons.image" +
                            " from  customers_vs_coupons join coupons" +
                            " where customers_vs_coupons.coupon_id = coupons.id" +
                            " and  customers_vs_coupons.customer_id=? ");
            statement.setInt(1, customerID);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                coupons.add(new Coupon(rs.getInt(1), rs.getInt(2),
                        Category.values()[rs.getInt(3) - 1], rs.getString(4), rs.getString(5),
                        rs.getDate(6), rs.getDate(7), rs.getInt(8), rs.getDouble(9), rs.getString(10)));
            }
            return coupons;
        } finally {
            pool.restoreConnection(con);
        }
    }
}
