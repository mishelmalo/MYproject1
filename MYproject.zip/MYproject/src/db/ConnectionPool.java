package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;

public class ConnectionPool {
    private static ConnectionPool instance;
    private ArrayList<Connection>connections;
    private static final int MAX_CONNECTION=5;

    private ConnectionPool() {
        connections=new ArrayList<>();
        for (int i = 0; i < MAX_CONNECTION; i++) {
            try {
                connections.add(DriverManager.getConnection("jdbc:mysql://localhost:3306/coupon_system?useUnicode=true&serverTimezone=UTC",
                        "root","Mishel0610$"));
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }

        }
    }
    public static ConnectionPool getInstance(){
        if(instance==null){
            instance=new ConnectionPool();
        }
        return instance;
    }
    public synchronized Connection getConnection(){
        while (connections.size()==0){
            try {
                wait();
            } catch (InterruptedException e) {}
        }
        Connection con=connections.get(connections.size()-1);
        connections.remove(connections.size()-1);
        return con;
    }
    public synchronized void restoreConnection(Connection con){
        connections.add(con);
        notify();
    }
public synchronized void CloseAllConnections(){
        while (connections.size()<MAX_CONNECTION){
            try {
                wait();
            } catch (InterruptedException e) {}
        }
        for (Connection con:connections){
            try {
                con.close();
            } catch (SQLException e) {}
        }
}
}
