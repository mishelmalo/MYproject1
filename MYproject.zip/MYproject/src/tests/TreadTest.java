package tests;

import Job.CouponExpirationDailyJob;

import java.util.ArrayList;
import java.util.List;

public class TreadTest {


    public static void main(String[] args) {
        Thread job=new Thread(new CouponExpirationDailyJob());
        job.start();
    }
}