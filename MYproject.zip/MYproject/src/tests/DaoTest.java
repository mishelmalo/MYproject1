package tests;

import DAO.CompanyDAO;
import DAO.CouponDAO;
import DAO.CustomerDAO;
import beans.Category;
import beans.Company;
import beans.Coupon;
import beans.Customer;
import db.*;

import java.sql.Date;
import java.sql.SQLException;
import java.util.Calendar;


public class DaoTest {
    public static void main(String[] args) throws SQLException {
        CustomerDAO customerDAO=new CustomerDAOImpl();
        CompanyDAO companyDAO=new CompanyDAOImpl();
        CouponDAO couponDAO=new CouponDAOImpl();
        //customerDAO

        Customer customer1=new Customer("michael","cohen","michael.cohen@gmail.com","misha");
        Customer customer2=new Customer("aharon","david","david_aharon@gmail.com","1234");
        Customer customer3=new Customer("shahaf","azulai","shahaf23@gmail.com","shasha12");
        System.out.println("add new customer");
        customerDAO.addCustomer(customer1);
        customerDAO.addCustomer(customer2);
         customerDAO.addCustomer(customer3);
       customerDAO.getAllCustomers().forEach(System.out::println);

        System.out.println("is customer exist?");
        System.out.println(customerDAO.isCustomerExist("michael.cohen@gmail.com","misha"));
        System.out.println(customerDAO.isCustomerExist("hchm","hgdkh"));

        System.out.println("update customer");
        customer2.setFirstName("misha");
        customer2.setLastName("inatayev");
        customerDAO.updateCustomer(4,customer2);
        customerDAO.getAllCustomers().forEach(System.out::println);

        System.out.println("delete customer");
        customerDAO.deltaCustomer(5);
        customerDAO.getAllCustomers().forEach(System.out::println);

        System.out.println("get one customer");
        System.out.println(customerDAO.getOneCustomer(3));
        System.out.println("******************************************************************");
        //companyDAO
        Company company1=new Company("ahava","ahava.co.il","1234a");
        Company company2=new Company("loreal","loreal_paris@gmail.com","lori234");
        Company company3=new Company("pizza_hut","pizzah@gmail.com","pis25");

        System.out.println("add new company");
        companyDAO.addCompany(company1);
        companyDAO.addCompany(company2);
        companyDAO.addCompany(company3);
        companyDAO.getAllCompanies().forEach(System.out::println);

        System.out.println("is company exist");
        System.out.println(companyDAO.isCompanyExist("ahava.co.il","1234a"));
        System.out.println(companyDAO.isCompanyExist("co.il","123a"));

        System.out.println("update company");
        company1.setPassword("1286");
        companyDAO.updateCompany(3,company1);
        companyDAO.getAllCompanies().forEach(System.out::println);

        System.out.println("delete company");
        companyDAO.deleteCompany(1);
        companyDAO.getAllCompanies().forEach(System.out::println);

        System.out.println("get one company");
        System.out.println(companyDAO.getOneCompany(2));
        System.out.println("******************************************");
       //couponDAO
        Calendar calendar=Calendar.getInstance();
        calendar.set(2022,6,9);
        Calendar calendar2=Calendar.getInstance();
        calendar.set(2022,7,4);

        Coupon coupon1=new Coupon(3, Category.COSMETICS_DEAL,"face_cream","face cream 20 ml  ",
                new Date(calendar.getTimeInMillis()),new Date(calendar2.getTimeInMillis()),13,98.9,"dx");

        Calendar calendar3=Calendar.getInstance();
        calendar3.set(2022,6,14);
        Calendar calendar4=Calendar.getInstance();
        calendar4.set(2022,7,23);

        Coupon coupon2=new Coupon(3, Category.COSMETICS_DEAL,"face_mask","face mask 30 ml  ",
                new Date(calendar3.getTimeInMillis()),new Date(calendar4.getTimeInMillis()),20,102.9,"dx");

        Calendar calendar5=Calendar.getInstance();
        calendar5.set(2022,6,13);
        Calendar calendar6=Calendar.getInstance();
        calendar6.set(2022,7,01);

        Coupon coupon3=new Coupon(3, Category.COSMETICS_DEAL,"face_mask","face mask 38 ml vanile  ",
                new Date(calendar5.getTimeInMillis()),new Date(calendar6.getTimeInMillis()),2,60,"x3");


        System.out.println("add coupon");
        couponDAO.addCoupon(coupon1);
         couponDAO.addCoupon(coupon2);
         couponDAO.addCoupon(coupon3);
        couponDAO.getAllCoupons().forEach(System.out::println);


        System.out.println("upadate coupon");
         coupon3.setAmount(11);
        couponDAO.updateCoupon(5,coupon3);
         couponDAO.getAllCoupons().forEach(System.out::println);

        System.out.println("delete coupon");
        couponDAO.deleteCoupon(4);
        couponDAO.getAllCoupons().forEach(System.out::println);
        System.out.println("get one coupon");
        System.out.println(couponDAO.getOneCoupon(3));

        System.out.println("customers_coupons purchase");
        couponDAO.addCouponPurchase(1,3);
        couponDAO.addCouponPurchase(2,3);
        System.out.println("delete coupon purchase");
        couponDAO.deleteCouponPurchase(2,3);



    }
}
