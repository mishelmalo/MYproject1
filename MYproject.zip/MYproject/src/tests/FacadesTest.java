package tests;

import DAO.CompanyDAO;
import DAO.CouponDAO;
import DAO.CustomerDAO;
import Exceptions.CouponSystemException;
import Facade.AdminFacade;
import Facade.CompanyFacade;
import Facade.CustomerFacade;
import beans.Category;
import beans.Company;
import beans.Coupon;
import beans.Customer;
import db.CompanyDAOImpl;
import db.CouponDAOImpl;
import db.CustomerDAOImpl;

import java.sql.Date;
import java.sql.SQLException;
import java.util.Calendar;

public class FacadesTest {
    public static void main(String[] args) throws CouponSystemException, SQLException {
        AdminFacade adminFacade=new AdminFacade();
        CompanyFacade companyFacade=new CompanyFacade();
        CustomerFacade customerFacade=new CustomerFacade();
        CompanyDAO companyDAO=new CompanyDAOImpl();
        CouponDAO couponDAO=new CouponDAOImpl();
        CustomerDAO customerDAO=new CustomerDAOImpl();

       //**************************admin facade************************
        System.out.println("login...");
       System.out.println(adminFacade.login("admin@admin.com","admin"));
        System.out.println(adminFacade.login("admin@admin.com","ain"));

        System.out.println("add company..");
        Company company1=new Company("pizza_hut","admin@admin.com","admin");
        Company company2=new Company("issta","admin@admin.com","admin");
        Company company3=new Company("ninja","admin@admin.com","admin");
        Company company4=new Company("issta","admin@admin.com","admin");
        Company company5=new Company("eroca","eroca132@gmail.com","eroca23");


        Company companyDb=companyDAO.getOneCompany(26);
       companyDb.setPassword("154");
        try {
           adminFacade.updateCompany(companyDb);
        } catch (SQLException | CouponSystemException e) {
            e.printStackTrace();
        }
        company5.setPassword("3321");

        adminFacade.addCompany(company1);
       adminFacade.addCompany(company2);
        adminFacade.addCompany(company3);
         adminFacade.addCompany(company4);
        adminFacade.getAllCompanies().forEach(System.out::println);

       System.out.println("update company");
  Company companydc=adminFacade.getOneCompany(7);
        companydc.setCompanyName("pizza_dhf");
        companydc.setPassword("dfeg");
        adminFacade.updateCompany(company4);
        adminFacade.getAllCompanies().forEach(System.out::println);

        System.out.println("delete company");
        adminFacade.deleteCompany(6);
        adminFacade.deleteCompany(8);

        System.out.println("get one company");

       System.out.println(adminFacade.getOneCompany(6));

       System.out.println("add new customer");
        Customer customer1=new Customer("alon","malka","alon123@gmail.com","alon234");
        Customer customer2=new Customer("mariana","levin","masha1258@gmail.com","mar857");
        Customer customer3=new Customer("yosi","moshe","yosi23@gmail.com","yossi374");
        Customer customer4=new Customer("eli","shabat","eli23652@gmail.com","eli481");
        adminFacade.addNewCustomer(customer1);
       adminFacade.addNewCustomer(customer2);
       adminFacade.addNewCustomer(customer3);
        adminFacade.addNewCustomer(customer4);
        adminFacade.getAllCustomers().forEach(System.out::println);
        customer1.setPassword("al532");
        adminFacade.updateCustomer(customer1);
        adminFacade.getAllCustomers().forEach(System.out::println);
        System.out.println("delete customer");
        adminFacade.deleteCustomer(13);
        adminFacade.deleteCustomer(12);
        adminFacade.getAllCustomers().forEach(System.out::println);
        System.out.println("get one company..");
        System.out.println(adminFacade.getOneCustomer(12));

         //**********company facade****************************

        Company company7=new Company("morphy richards","morprr13@gmail.com","mort255");
         companyDAO.addCompany(company7);

        System.out.println("company login");
      System.out.println(companyFacade.login("morprr13@gmail.com","mort255"));

        System.out.println("add company");

        Calendar calendar1=Calendar.getInstance();
        calendar1.set(2022,7,14);
        Calendar calendar2=Calendar.getInstance();
        calendar2.set(2022,8,23);

        Coupon coupon1=new Coupon(9,Category.ELECTRICITY,"morphy richards blander","morphy richards blander 1.5 liter",
                new Date(calendar1.getTimeInMillis()),new Date(calendar2.getTimeInMillis()),42,128,"fsd");

        Calendar calendar3=Calendar.getInstance();
        calendar3.set(2022,7,22);
        Calendar calendar4=Calendar.getInstance();
        calendar4.set(2022,8,29);

        Coupon coupon2=new Coupon(9,Category.ELECTRICITY,"mini morphy richards blander","morphy richards blander 1 liter",
                new Date(calendar3.getTimeInMillis()),new Date(calendar4.getTimeInMillis()),32,98.5,"sfsd");

        Coupon coupon3=new Coupon(9,Category.ELECTRICITY,"morphy richards blander","morphy richards blander 1 liter",
                new Date(calendar3.getTimeInMillis()),new Date(calendar4.getTimeInMillis()),32,98.5,"sfsd");
        companyFacade.addCoupon(coupon1);
        companyFacade.addCoupon(coupon2);
        companyFacade.addCoupon(coupon3);
        coupon1.setTitle("large morphy richards blander ");
        companyFacade.updateCoupon(coupon1);
        coupon1.setTitle(" morphy richards blander ");
        companyFacade.updateCoupon(coupon1);
        companyFacade.deleteCoupon(17);
        System.out.println(companyFacade.getAllCompanyCoupons());
        System.out.println(companyFacade.getAllCompanyCouponsOnOneCategory(Category.ELECTRICITY));
        System.out.println(companyFacade.getAllCompanyCouponsLimitedByMaxPrice(99));
      System.out.println(companyFacade.getCompanyThatLogin());

        //**********************CustomerFacade***************************

        Customer customer10=new Customer("yuli","yako","yulik124@gmail.com","yuli99");
        Customer customer11=new Customer("mor","yosef","mory46@gmail.com","mori34");
        Customer customer12=new Customer("yuval","yuvi","yuval3424@gmail.com","yuvi44659");
        customerDAO.addCustomer(customer10);
        customerDAO.addCustomer(customer11);
        customerDAO.addCustomer(customer12);
       System.out.println("login");
        System.out.println(customerFacade.login("yulik124@gmail.com","yui99"));//should fail
        System.out.println(customerFacade.login("mory46@gmail.com","mori34"));//working!
        System.out.println(customerFacade.login("mory86@gmail.com","mori34")); //should gail

        Company company10=new Company("rob roy","rob_roy@gmail.com","robi35");
        companyDAO.addCompany(company10);

        Calendar calendar5=Calendar.getInstance();
        calendar5.set(2022,6,22);
        Calendar calendar6=Calendar.getInstance();
        calendar6.set(2022,8,29);

        Coupon coupon10=new Coupon(19,10,Category.SPORT_ACTIVITIES,"a cruise on the jorden sea of galilee"
                ,"cruise  on rafts and kayaks for couple",new Date(calendar5.getTimeInMillis()),
                new Date(calendar6.getTimeInMillis()),10,125,"gfk");

        Calendar calendar7=Calendar.getInstance();
        calendar7.set(2022,5,01);
        Calendar calendar8=Calendar.getInstance();
        calendar8.set(2022,5,17);

        Coupon coupon11=new Coupon(20,10,Category.SPORT_ACTIVITIES,"a cruise on the  sea of galilee"
                ,"cruise  on rafts and kayaks for 4",new Date(calendar7.getTimeInMillis()),
                new Date(calendar8.getTimeInMillis()),1,199,"gfk");

        couponDAO.addCoupon(coupon10);
        couponDAO.addCoupon(coupon11);
        System.out.println("purchase coupon");
        couponDAO.addCouponPurchase(17,16);

        couponDAO.addCouponPurchase(17,19);
        customerFacade.purchaseCoupon(coupon10);
        customerFacade.purchaseCoupon(coupon10);
        customerFacade.purchaseCoupon(coupon11);
         coupon10.setAmount(0);
        couponDAO.updateCoupon(19,coupon10);
        customerFacade.purchaseCoupon(coupon10);
        System.out.println("get customer coupons");
        System.out.println(customerFacade.getCustomerCoupons());
        System.out.println(customerFacade.getAllCustomersCouponsByCategory(Category.SPORT_ACTIVITIES));
        System.out.println(customerFacade.getAllCustomersCouponsUnderMaxPrice(124));
        System.out.println("get customer details");
        System.out.println(customerFacade.getCustomerDetails());
        System.out.println("get all coupons");
        System.out.println(customerFacade.couponsForChoose());










    }
}
