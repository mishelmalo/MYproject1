package Job;

import DAO.CouponDAO;
import beans.Coupon;
import db.CouponDAOImpl;

import java.sql.SQLException;
import java.util.Calendar;
import java.util.List;

public class CouponExpirationDailyJob implements java.lang.Runnable {
   private CouponDAO couponDAO=new CouponDAOImpl();
    private boolean quit = false;

    public CouponExpirationDailyJob() {   }


    public void stop(){
        quit = true;
    }

    @Override
    public void run() {
        while(!quit){
            // get all coupons
            try {
            List<Coupon> coupons =couponDAO.getAllCoupons();
            // get current time
            Calendar now=Calendar.getInstance();
            // check coupons date - current date and delete if needed
            for (int i = 0; i <coupons.size() ; i++) {
                if(now.getTimeInMillis()>coupons.get(i).getEndDate().getTime()){
                        couponDAO.deleteCoupon(coupons.get(i).getId());
                    }
                }
            }catch (SQLException e) {
                e.printStackTrace();
            }// sleep for 24 hours
            try {
                Thread.sleep(24*60*60*1000);

            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }
}
