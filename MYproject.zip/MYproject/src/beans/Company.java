package beans;

import java.util.ArrayList;
import java.util.List;

public class Company {
    private int id;
    private String companyName,email,password;
    private List<Coupon> companyCoupons;

    public Company( String companyName, String email, String password) {
        this.companyName = companyName;
        this.email = email;
        this.password = password;

    }
    public Company(int id, String companyName, String email, String password, List<Coupon> companyCoupons) {
        this.id = id;
        this.companyName = companyName;
        this.email = email;
        this.password = password;
        this.companyCoupons =companyCoupons;
    }

    public int getId() {
        return id;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<Coupon> getCompanyCoupons() {
        return  companyCoupons;
    }

    public void setCoupons(ArrayList<Coupon> companyCoupons) {
        this.companyCoupons = companyCoupons;
    }

    @Override
    public String toString() {
        return "Company{" +
                "id=" + id +
                ", companyName='" + companyName + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", company coupons=" + companyCoupons +
                '}';
    }
}
